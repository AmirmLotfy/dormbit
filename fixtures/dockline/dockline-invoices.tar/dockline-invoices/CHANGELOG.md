# Changelog

## 0.1.0 (2025-05-02)

- Customers, invoices, and line items
- Tax rates per invoice
- Paginated invoice list
- Tax rounds once, on the subtotal
