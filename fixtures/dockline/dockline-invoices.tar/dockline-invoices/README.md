# Dockline Invoices

Invoicing for a small marine supply shop: customers, invoices with line items and tax, and
(soon) PDF export.

## Run it

```sh
npm install
npm run db:push
npm run api   # http://localhost:3001
npm run dev   # http://localhost:5173
```

Copy `.env.example` to `.env` first.
