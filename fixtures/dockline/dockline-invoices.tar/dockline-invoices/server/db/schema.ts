import { integer, real, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const customers = sqliteTable("customers", {
  id: integer("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
});

export const invoices = sqliteTable("invoices", {
  id: integer("id").primaryKey(),
  customerId: integer("customer_id").references(() => customers.id),
  issuedOn: text("issued_on").notNull(),
  taxRate: real("tax_rate").notNull().default(0.0825),
});

export const lineItems = sqliteTable("line_items", {
  id: integer("id").primaryKey(),
  invoiceId: integer("invoice_id").references(() => invoices.id),
  description: text("description").notNull(),
  quantity: integer("quantity").notNull(),
  unitCents: integer("unit_cents").notNull(),
});
