import { db } from "./client";
import { customers, invoices } from "./schema";

await db.insert(customers).values([
  { id: 1, name: "Harbor Light Charters", email: "billing@harborlight.invalid" },
  { id: 2, name: "Pelican Point Marina", email: "office@pelicanpoint.invalid" },
]);
await db.insert(invoices).values([{ id: 1, customerId: 1, issuedOn: "2025-03-20" }]);
