import Fastify from "fastify";
import cors from "@fastify/cors";
import { health } from "./routes/health";
import { invoices } from "./routes/invoices";

const app = Fastify({ logger: true });
await app.register(cors);
await app.register(health);
await app.register(invoices, { prefix: "/api" });
await app.listen({ port: 3001 });
