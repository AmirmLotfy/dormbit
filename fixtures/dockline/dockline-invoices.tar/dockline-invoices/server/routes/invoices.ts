import type { FastifyInstance } from "fastify";
import { db } from "../db/client";
import { invoices } from "../db/schema";

const PAGE = 25;

export async function invoices(app: FastifyInstance) {
  app.get<{ Querystring: { page?: string } }>("/invoices", async (req) => {
    const page = Math.max(0, Number(req.query.page ?? 0));
    return db.select().from(invoices).limit(PAGE).offset(page * PAGE);
  });
}
