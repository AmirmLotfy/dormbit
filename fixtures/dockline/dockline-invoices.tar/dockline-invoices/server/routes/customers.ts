import type { FastifyInstance } from "fastify";
import { db } from "../db/client";
import { customers } from "../db/schema";

export async function customersRoutes(app: FastifyInstance) {
  app.get("/customers", async () => db.select().from(customers));
  app.post<{ Body: { name: string; email?: string } }>("/customers", async (req, reply) => {
    if (!req.body.name.trim()) return reply.code(400).send({ error: "name is required" });
    return db.insert(customers).values(req.body).returning();
  });
}
