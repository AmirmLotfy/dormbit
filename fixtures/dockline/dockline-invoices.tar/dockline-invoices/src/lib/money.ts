export type Line = { quantity: number; unitCents: number };

export function subtotalCents(lines: Line[]): number {
  return lines.reduce((sum, l) => sum + l.quantity * l.unitCents, 0);
}

/** Rounds half up to whole cents, once, on the subtotal. */
export function taxCents(subtotal: number, rate: number): number {
  return Math.round(subtotal * rate);
}
