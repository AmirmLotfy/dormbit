import { describe, expect, it } from "vitest";
import { subtotalCents, taxCents } from "./money";

describe("money", () => {
  it("adds line items", () => {
    expect(subtotalCents([{ quantity: 2, unitCents: 1250 }, { quantity: 1, unitCents: 499 }])).toBe(2999);
  });
  it("rounds tax to whole cents", () => {
    expect(taxCents(2999, 0.0825)).toBe(247);
  });
});
