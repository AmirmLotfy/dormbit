import { describe, expect, it } from "vitest";
import { renderInvoice } from "./renderInvoice";

describe("renderInvoice", () => {
  it("returns a PDF blob", async () => {
    const blob = await renderInvoice(1);
    expect(blob.type).toBe("application/pdf");
  });
  it.skip("prints totals that match the invoice", async () => {
    // Waiting on the totals block (see the FIXME in renderInvoice.ts).
  });
});
