import { PDFDocument, StandardFonts } from "pdf-lib";
import { subtotalCents, taxCents } from "../lib/money";

export async function renderInvoice(id: number): Promise<Blob> {
  const invoice = await fetch(`/api/invoices/${id}`).then((r) => r.json());
  const doc = await PDFDocument.create();
  const page = doc.addPage();
  const font = await doc.embedFont(StandardFonts.Helvetica);
  page.drawText(`Invoice #${invoice.id}`, { x: 50, y: 760, size: 18, font });
  invoice.lines.forEach((l: { description: string }, i: number) => {
    page.drawText(l.description, { x: 50, y: 720 - i * 18, size: 11, font });
  });
  const subtotal = subtotalCents(invoice.lines);
  // TODO: totals block (subtotal, tax, total) aligned right
  // FIXME: tax is computed per line here, which double-rounds; use taxCents(subtotal) once
  const tax = taxCents(subtotal, invoice.taxRate); // trying the shared helper
  page.drawText(`Subtotal ${(subtotal / 100).toFixed(2)}`, { x: 360, y: 140, size: 12, font });
  page.drawText(`Total ${((subtotal + tax) / 100).toFixed(2)}`, { x: 360, y: 120, size: 12, font });
  return new Blob([await doc.save()], { type: "application/pdf" });
}
