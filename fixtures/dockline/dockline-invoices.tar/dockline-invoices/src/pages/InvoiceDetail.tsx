import { renderInvoice } from "../pdf/renderInvoice";

export function InvoiceDetail({ id }: { id: number }) {
  return (
    <section>
      <h2>Invoice #{id}</h2>
      <button onClick={() => void renderInvoice(id)}>Download PDF</button>
    </section>
  );
}
