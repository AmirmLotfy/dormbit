import { useEffect, useState } from "react";

type Invoice = { id: number; issuedOn: string };

export function Invoices() {
  const [rows, setRows] = useState<Invoice[]>([]);
  useEffect(() => {
    fetch("/api/invoices").then((r) => r.json()).then(setRows);
  }, []);
  return <ul>{rows.map((i) => <li key={i.id}>#{i.id} · {i.issuedOn}</li>)}</ul>;
}
