import { Invoices } from "./pages/Invoices";

export function App() {
  return (
    <main>
      <h1>Dockline Invoices</h1>
      <Invoices />
    </main>
  );
}
