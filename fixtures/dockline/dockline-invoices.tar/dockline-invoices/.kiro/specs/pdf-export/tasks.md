# Implementation plan

- [x] 1. Add a renderInvoice entry point
- [x] 2. Lay out the header and line items
- [x] 3. Wire the Download PDF button
- [ ] 4. Compute totals with the shared money helpers
- [ ] 5. Embed the shop logo
- [ ] 6. Snapshot-test the rendered PDF
- [ ] 7. Document PDF export in the README
