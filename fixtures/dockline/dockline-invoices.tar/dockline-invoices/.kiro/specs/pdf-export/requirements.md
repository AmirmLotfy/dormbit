# PDF export

## Requirement 1

WHEN the user clicks Download PDF on an invoice, THE app SHALL produce a PDF with the header,
line items, subtotal, tax, and total.
