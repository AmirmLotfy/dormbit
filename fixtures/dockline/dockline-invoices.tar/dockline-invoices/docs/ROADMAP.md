# Roadmap

- [x] Customers and invoices
- [x] Tax rates per invoice
- [ ] PDF export (spec in `.kiro/specs/pdf-export`), totals still wrong
- [ ] Email invoices to customers
- [ ] Rate limits on the API (started, see stash)
- [ ] Multi-currency
