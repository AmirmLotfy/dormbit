# PDF ideas

- Use the shared taxCents helper so the PDF matches the web total.
- Logo top left, invoice number top right.
- Ask Theo whether pdf-lib can embed the marina's font.
